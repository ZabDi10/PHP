


   /* let imagenes=document.querySelectorAll(".imageZ");
    imagenes.forEach(items=>{
        items.addEventListener("mouseover",()=>{
            items.style.opacity="0.2";

        });
        items.addEventListener("mouseout", ()=>{
            items.style.opacity="1";



        })
    })*/


