<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">

            <a href="index.php" class="menuItem">Inicio</a>
            <a href="tienda.php" class="menuItem">Tienda</a>
            <a href="contacto.php" class="menuItem">Contacto</a>

    </div>
</body>
</html>