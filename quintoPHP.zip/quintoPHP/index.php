<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manejo de datos desde HTML y PHP</title>
</head>
<body>
<?php
include 'header.php';
?>





<?php
include 'footer.php';
?>

</body>
</html>