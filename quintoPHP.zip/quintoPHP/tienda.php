<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tienda</title>
</head>
<body>
<?php
include 'header.php';
?>





<?php
include 'footer.php';
?>
</body>
</html>