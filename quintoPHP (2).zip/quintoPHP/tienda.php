<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tienda</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
include 'header.php';
?>
<div class="falsa"></div>
<div class="iconos salto">

    <img src="img/berserk41.webp">
    <div>
        <p>17€</p>
    </div>
</div>
<div class="iconos salto">

    <img src="img/yumi.jpg">
    <div>
        <p>20€</p>
    </div>
</div>
<div class="iconos salto">

    <img src="img/jujutsu.jpeg">
    <div>
        <p>8€</p>
    </div>
</div>



<?php
include 'footer.php';
?>
</body>
</html>