<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="header">
 <div class="verde">
    <div class="container1">
            <a href="#" class="menuItem">Direccion</a>
            <a href="#" class="menuItem">Tu pedido</a>
            <a href="#" class="menuItem3">Conocenos</a>
    </div>
 </div>
        <div class="container2">

            <a href="index.php" class="menuItem">Inicio</a>
            <a href="tienda.php" class="menuItem">Tienda</a>
            <a href="contacto.php" class="menuItem">Contacto</a>

        </div>
    <hr class="raya">

    </div>

</body>
</html>