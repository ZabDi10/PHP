<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <div  class = "footer1">
        <div>
            <a href="#">C\ EnUnMundoIdeal, n87</a>
        </div>
    </div>
</body>
</html>